
<?php
// Callback function for displaying the team members table
function team_members_display_table() {
    $current_user_id = get_current_user_id();
    
    if(current_user_can('administrator')){
        $query = new WP_Query( array(
            'post_type'      => 'team_member',
            'posts_per_page' => -1,
        ) );
    }
    else{
        $query = new WP_Query( array(
            'post_type'      => 'team_member',
            'posts_per_page' => -1,
            'author'         => $current_user_id,
        ) );
    }
   
    ?>
    <div class="wrap">
    <h1>Team Members Table</h1>
        <div class="team-members-table">
        
        <div class="table-header">
            <ul>
         
                <li><b>Member Management</b></li>
               
                <li>Evaluate</li>
                <li>Leader Board</li>
                <li><a href="/teams/wp-admin/post-new.php?post_type=team_member"><button>Add Member</button></a></li>
            </ul>
        </div>
        <table id="team-members-table" class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>WebHR Id</th>
                    <th>Role Category</th>
                    <th>Reporting To</th>
                    <th>Lead</th>
                    <th>Lead %</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                
                $counter = 1;
                while ( $query->have_posts() ) : $query->the_post();
                $post_ID = get_the_ID();
                $post_slug = get_post_field('post_name', get_post()); ?>

                    <?php
                    $name = get_post_meta( get_the_ID(), '_team_member_name', true );
                    $designation = get_post_meta( get_the_ID(), '_team_member_designation', true );
                    $email = get_post_meta( get_the_ID(), '_team_member_email', true );
                    $webhr_id = get_post_meta( get_the_ID(), '_team_member_webhr_id', true );
                    $report_to = get_post_meta( get_the_ID(), '_team_member_report_to', true );
                    $is_lead = get_post_meta( get_the_ID(), '_team_member_is_lead', true );
                    $member_status = get_post_meta( get_the_ID(), '_team_member_status', true ); 
                    if($is_lead == "Yes"){
                    $percentage = get_post_meta( get_the_ID(), '_team_member_percentage', true ) . "%";
                    }
                    else{
                        $percentage = "-";
                    }
                    if($name){
                    ?>

                    <tr>
                        <td><?php echo $counter;?></td>
                        <td><?php echo esc_html($name);?></td>
                        <td><?php echo esc_html( $webhr_id ); ?></td>
                        <td><?php echo esc_html( $designation ); ?></td>
                        <td><?php echo esc_html( $report_to ); ?></td>
                        <td><?php echo esc_html( $is_lead ); ?></td>
                        <td><?php echo esc_html($percentage);?></td>
                        <td><?php echo esc_html($member_status);?></td>
                        <td><a href="/teams/wp-admin/post.php?post=<?php echo $post_ID ;?>&action=edit"><span class="dashicons dashicons-edit"></span></a>
                        <a href="/teams/index.php/team_member/<?php echo $post_slug?>"><i class="fa fa-eye" aria-hidden="true"></i></a>
                        </td>
                        
                    </tr>
                <?php 
                    }
             $counter++;
            endwhile; 
           ?>
            </tbody>
        </table>
        </div>
    </div>
    <?php
    wp_reset_postdata();
}


// Display the content of the evaluate table
function team_members_evaluate_page() {
    $current_user_id = get_current_user_id();
    
   if(current_user_can('administrator')){
        $query = new WP_Query( array(
            'post_type'      => 'team_member',
            'posts_per_page' => -1,
        ) );
   }
    else{
        $query = new WP_Query( array(
            'post_type'      => 'team_member',
            'posts_per_page' => -1,
            'author'         => $current_user_id,
        ) );
    }
   
    ?>
    <div class="wrap">
    <h1>Evaluate Table</h1>
        <div class="team-members-table">
        
        <div class="e-table-header">
            <ul>
    
                <li>Member Management</li>
             
                <li><b>Evaluate</b></li>
                <li>Leader Board</li>
            </ul>
        </div>
        <form method="post">
        <table id="team-members-evaluate-table" class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th data-filter-type="none">Name</th>
                    <th data-filter-type="none">Work Rating</th>
                    <th data-filter-type="none">Comments</th>
                    <th data-filter-type="none">Team Management Rating</th>
                    <th data-filter-type="none">Comments</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                while ( $query->have_posts() ) : $query->the_post();
                   
              
                   $name = get_post_meta( get_the_ID(), '_team_member_name', true );
                   $designation = get_post_meta( get_the_ID(), '_team_member_designation', true );
                   $email = get_post_meta( get_the_ID(), '_team_member_email', true );
                   $webhr_id = get_post_meta( get_the_ID(),'_team_member_webhr_id', true );
                   $report_to = get_post_meta( get_the_ID(), '_team_member_report_to', true );
                   $is_lead = get_post_meta( get_the_ID(), '_team_member_is_lead', true );
                   $percentage = get_post_meta( get_the_ID(), '_team_member_percentage', true );
                   $member_status = get_post_meta( get_the_ID(), '_team_member_status', true );
               //    $lead_username = get_post_meta( get_the_ID(),'_team_member_username', true );
                   $lead_password = get_post_meta( get_the_ID(), '_team_member_password', true );
                   
                    $work_rating_value = get_post_meta(get_the_ID(), '_team_member_work_rating_value', true);
                    $work_rating_comment = get_post_meta(get_the_ID(), '_team_member_work_rating_comment', true);
                    $management_rating = get_post_meta(get_the_ID(), '_team_member_management_rating', true);
                    $management_comment = get_post_meta(get_the_ID(), '_team_member_management_comment', true);

                    $is_lead = get_post_meta( get_the_ID(), '_team_member_is_lead', true );
                   //if($is_lead == "Yes"){
                    if($name ){
                    ?>

                    <tr>
                     
                    <td><?php echo esc_html($name);?></td>
                    <td>
                        <span class="work-rating-value"><?php echo esc_html($work_rating_value);?></span>
                        <input type="number" id="team_member_work_rating_<?php the_ID(); ?>" class="work-rating-value-field" name="team_member_work_rating_<?php the_ID(); ?>" value="<?php echo esc_html($work_rating_value);?>" />
                    </td>
                        <td>
                        <span class="work-rating-comment"> <?php echo esc_html($work_rating_comment);?></span>
                        <input type="text" id="team_member_work_rating_comment_<?php the_ID(); ?>" class="work-rating-comment-field" name="team_member_work_rating_comment_<?php the_ID(); ?>" value="<?php echo esc_html($work_rating_comment);?>" />
                        </td>
                        <td>
                       <?php  if($is_lead == "Yes"){?>
                            <span class="team-management-value"><?php echo esc_html($management_rating);?></span>
                        <input type="number" id="team_member_management_<?php the_ID(); ?>" class="team-management-value-field" name="team_member_management_<?php the_ID(); ?>" value="<?php echo esc_attr( $management_rating ); ?>" />
                        <?php }?>
                    </td>
                        
                    <td> <?php  if($is_lead == "Yes"){?>
                        <span class="work-management-comment"><?php echo esc_html($management_comment);?></span>
                        <input type="text" id="team_member_work_management_comment_<?php the_ID(); ?>" class="work-management-comment-field" name="team_member_work_management_comment_<?php the_ID(); ?>" value="<?php echo esc_html($management_comment);?>" />
                        <?php }?> </td>

                    </tr>
                <?php
                   }

            // Check if the form is submitted
            if ( isset( $_POST['submit_evaluation'] ) ) {
                ini_set( 'display_errors', 1 );
                error_reporting( E_ALL );
                // Get the current team member post ID
                $post_id = get_the_ID();

                // Update the post meta values
                $work_rating_value = intval( $_POST['team_member_work_rating_' . $post_id] );
                $work_rating_comment = sanitize_text_field( $_POST['team_member_work_rating_comment_' . $post_id] );
                if($is_lead == "Yes"){
                $management_rating = intval( $_POST['team_member_management_' . $post_id] );
                $management_comment = sanitize_text_field( $_POST['team_member_work_management_comment_' . $post_id] );
                 }
        

                update_post_meta( $post_id, '_team_member_work_rating_value', $work_rating_value );
                update_post_meta( $post_id, '_team_member_work_rating_comment', $work_rating_comment );
                update_post_meta( $post_id, '_team_member_management_rating', $management_rating );
                update_post_meta( $post_id, '_team_member_management_comment', $management_comment );


                // Check if the record already exists in the custom table
                global $wpdb;

                $current_week = date( 'W' );
                $current_year = date( 'Y' );
                $existing_record = $wpdb->get_row(
                    $wpdb->prepare(
                        "SELECT * FROM {$wpdb->prefix}team_members WHERE post_id = %d AND week_number = %d AND year = %d",
                        $post_id,
                        $current_week,
                        $current_year
                    )
                );

                if ( $existing_record ) {
                   
                    // Update the existing record
              
                    $data = array(
                        'work_rating_value' => $work_rating_value,
                        'work_rating_comment' => $work_rating_comment,
                        'management_rating' => $management_rating,
                        'management_comment' => $management_comment,
                    );

                    $wpdb->update( $wpdb->prefix . 'team_members', $data, array( 'post_id' => $post_id, 'week_number' => $current_week, 'year' => $current_year ) );
                } 
                else {
                    $data = array(
                        'post_id' => $post_id,
                        'user_name' => $name,
                        'user_designation' => $designation,
                        'user_email' => $email,
                        'user_webhrID' => $webhr_id,
                        'user_report_to' => $report_to,
                        'user_is_lead' => $is_lead,
                        'user_lead_percentage' => $percentage,
                        'user_status' => $member_status,
                        'lead_username' => '',
                        'lead_password' => $lead_password,
                        'work_rating_value' => $work_rating_value,
                        'work_rating_comment' => $work_rating_comment,
                        'management_rating' => $management_rating,
                        'management_comment' => $management_comment,
                        'week_number'  => $current_week,
                        'year'  => $current_year,
                    );

                    $wpdb->insert( $wpdb->prefix . 'team_members', $data );
                }
        }

            endwhile; 
            if ( isset( $_POST['submit_evaluation'] ) ) {
                echo '<div class="notice notice-success"><p>Evaluation data submitted successfully.</p></div>';
            }
             
           ?>
            </tbody>
        </table>
        <div class="edit-button">
            <button class="edit-evaluation">Edit</button>
            <button class="save-evaluation" name="submit_evaluation">Submit</button>
        </div>
        </form>
        </div>
    </div>
    <?php
    wp_reset_postdata();
}

// Display the content of the Leader Board
add_shortcode('leaderboard_view', 'team_members_leaderboard_page');
function team_members_leaderboard_page() {
    error_reporting(E_ALL);
ini_set('display_errors', 1);
    $current_user_id = get_current_user_id();
    
  //  if(current_user_can('administrator')){

      
   
    ?>
    <div class="wrap">
        <div class="leaderboard-view">
        <div><h1>Leaderboard</h1></div>
        <div class="table-custom-filters">

        </div>

        </div>
  
        <div class="team-members-table">
        
        <div class="e-table-header">
            <ul>
                <li>Member Management</li>
                <li>Evaluate</li>
                <li><b>Leader Board</b></li>
            </ul>
        </div>
        <table id="team-members-leaderboard" class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th>Rank</th>
                <th>Name</th>
                <th>Role</th>
                <th>Week</th>
                <th>Quantity</th>
                <th>Quality</th>
                <th>Overall</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            
            $counter = 1;
            //    while ( $query->have_posts() ) : $query->the_post();
            // Loop through the results
            global $wpdb;

            // Define the table name
            $table_name = $wpdb->prefix . 'team_members';
            // Prepare and execute the SQL query
            $query = $wpdb->prepare( "SELECT * FROM $table_name" );
            $results = $wpdb->get_results( $query );
            if ( ! empty( $results ) ) {
                foreach ( $results as $result ) {
                    // Access the values
                    $name = $result->user_name;
                    $designation = $result->user_designation;
                    $percentage = $result->user_lead_percentage;
                    $is_lead = $result->user_is_lead;
                    $user_report_to = $result->user_report_to;
                    $work_rating_value = $result->work_rating_value;
                    $management_rating = $result->management_rating;
                    $week = $result->week_number;
                    $leaves_hours = $result->user_on_leaves;
                    $jira_log_hours = $result->jira_work_logs;
                    
 
                    if($name && $user_report_to != "None"){

                    
                    if( $is_lead){
                    $percentage = intval($percentage);
                    }
                    else{
                    $percentage = 0;
                    }
                  //  if( $is_lead == "Yes" && !empty ($work_rating_value) && !empty ($work_rating_comment) && !empty ($management_rating) && !empty ($management_comment)){
                
                    $quality_value = ($management_rating/10) * $percentage + ($work_rating_value/10) * (100-$percentage);
                    
                    $work_hours = 40 - $leaves_hours;
                    if( $work_hours == 0 && $jira_log_hours == 0){
                        $quantity_value = "NA";
                        $overall_value = "NA";
                        
                    }
                    elseif($work_hours == 0 && $jira_log_hours > 0){
                        $quantity_value = 100;
                       
                    }
                    else{
                        $quantity_value = $jira_log_hours / $work_hours * 100;
                        $overall_value = $quality_value * $quantity_value;

                          $quantity_value = round($quantity_value);
                          $overall_value = round($overall_value);
                    }
    
                     $quality_value = round($quality_value);
    
    
                     $quantity_box_color = '';
                     $quality_box_color = '';
                     $overall_box_color = '';

                     if ($quantity_value >= 80 && $quantity_value != "NA") {
                         $quantity_box_color = "green";
                     } elseif ($quantity_value >= 60 && $quantity_value < 80 && $quantity_value != "NA") {
                         $quantity_box_color = "yellow";
                     } elseif ($quantity_value < 60 && $quantity_value != "NA") {
                         $quantity_box_color = "red";
                     } else {
                         $quantity_box_color = "grey";
                     }

                     if ($quality_value < 60 && $quality_value != "NA") {
                         $quality_box_color = "red";
                     } elseif ($quality_value >= 60 && $quality_value < 80 && $quality_value != "NA") {
                         $quality_box_color = "yellow";
                     } elseif ($quality_value >= 80 && $quality_value != "NA") {
                         $quality_box_color = "green";
                     } else {
                         $quality_box_color = "grey";
                     }

                     if ($overall_value < 60 && $overall_value != "NA") {
                         $overall_box_color = "red";
                     } elseif ($overall_value >= 60 && $overall_value < 80 && $overall_value != "NA") {
                         $overall_box_color = "yellow";
                     } elseif ($overall_value >= 80 && $overall_value != "NA") {
                         $overall_box_color = "green";
                     } else {
                         $overall_box_color = "grey";
                     }
        
                     ?>
                     <tr>
                         <td><?php echo $counter; ?></td>
                         <td><?php echo esc_html($name); ?></td>
                         <td><?php echo esc_html($designation); ?></td>
                         <td><?php echo esc_html($week); ?></td>
                         <td><span class="<?php echo $quantity_box_color; ?>"><?php echo ($quantity_value != "NA") ? esc_html($quantity_value) . "%" : "NA"; ?></span></td>
                         <td><span class="<?php echo $quality_box_color; ?>"><?php echo ($quality_value != "NA") ? esc_html($quality_value) . "%" : "NA"; ?></span></td>
                         <td><span class="<?php echo $overall_box_color; ?>"><?php echo ($overall_value != "NA") ? esc_html($overall_value) . "%" : "NA"; ?></span></td>                        
                     </tr>
    
                <?php 
                    $counter++;
                    
                   // }
            
          //  endwhile; 
            
                }
            }

            }
                else {
                    echo "<tr><td>No results found.</td></tr>";
                }  
               
?>
             
        </tbody>
        </table>
        </div>
    </div>
    <?php
    wp_reset_postdata();
}


