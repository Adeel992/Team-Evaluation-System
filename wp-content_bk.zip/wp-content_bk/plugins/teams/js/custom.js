

jQuery(document).ready(function () {

    jQuery.extend(jQuery.fn.dataTableExt.oSort, {
        "percentage-pre": function (a) {
          var x = (a == "-") ? 0 : a.replace("%", "").replace(",", ".");
          return parseFloat(x);
        },
      
        "percentage-asc": function (a, b) {
          return ((a < b) ? -1 : ((a > b) ? 1 : 0));
        },
      
        "percentage-desc": function (a, b) {
          return ((a < b) ? 1 : ((a > b) ? -1 : 0));
        }
      });

    jQuery('#team-members-table').DataTable({
        columnDefs: [
            {
                target: 7,
                visible: false,
                searchable: true,
            },
        ],
        info: false,
        "lengthChange": false,
        "ordering": false,
    });

    jQuery('#team-members-evaluate-table').DataTable({
        info: false,
        "paging": false,
        "lengthChange": false,
        "ordering": false,
    });
 
      
    var leaderboard = jQuery('#team-members-leaderboard').DataTable({
        columnDefs: [
            {
                target: 3,
                visible: false,
                searchable: true,
            },
            {
                searchable: false,
                orderable: false,
                targets: 0,
            },

            { 
                targets: 6,
                orderable: true,
            },
            
        ],
        "order": [[6, 'desc'], [1, 'asc']],
        "info": false,
        "paging": false,
        "lengthChange": false,
        //"ordering": false,
    });
    jQuery('#team-members-leaderboard thead th').off('click');
    leaderboard.on('order.dt search.dt', function () {
        let i = 1;
 
        leaderboard.cells(null, 0, { search: 'applied', order: 'applied' }).every(function (cell) {
            this.data(i++);
        });
    }).draw();

    // Add dropdown filter for Status column
  var statusFilter = jQuery('<select id="status-filter"><option value="">All</option><option value="active">Active</option><option value="inactive">Inactive</option></select>');
  jQuery('#team-members-table_filter').prepend(statusFilter);

  // Apply filter on change
  var table = jQuery('#team-members-table').DataTable();

  statusFilter.on('change', function() {
    
      var status = jQuery(this).val();
      if (status === 'active') {
        table.column(7).search('^Active$', true, false).draw();
        } else if (status === 'inactive') {
            table.column(7).search('^Inactive$', true, false).draw();
        } else {
            table.column(7).search('').draw();
        }
  });


  var weekFilter = jQuery('<label>Week<select id="week-filter"><option value="">Select Week</option></select></label>');
  jQuery('.table-custom-filters').append(weekFilter);

  var roleFilter = jQuery('<label>Role Category<select id="role-filter"><option><option value="" selected>All</option>Unit Head</option><option>QA</option><option>QA Automation</option><option>Development</option><option>Dev Ops</option><option>GIS</option>s<option>Project Management</option><option>Implementation</option><option>SAP</option><option>Design</option><option>Product Management</option></select></label>');
  jQuery('.table-custom-filters').append(roleFilter);

    // Add dropdown filter for weeks column in leaderboard
    var currentDate = moment();
    var currentWeek = currentDate.isoWeek();

  // Create an array of previous weeks
    var previousWeeks = Array.from({ length: currentWeek }, (_, i) => i + 1);

    // Loop through previous weeks using foreach
    previousWeeks.forEach(function (week) {
    var weekLabel = "Week " + week;

            // Create list item and append to the week list
            var listItem = jQuery("<option>").text(weekLabel).val(week);
            // Check if it's the current week and set selected attribute
                if (week === currentWeek) {
                    listItem.attr("selected", "");
                }
            jQuery("#week-filter").append(listItem);
            
        });
    
  
    // Apply filter on change week and role category
    var table = jQuery('#team-members-leaderboard').DataTable();
    weekFilter.find("#week-filter").on('change', function() {
        var week_status = jQuery(this).val();
        table.column(3).search('\\b' + week_status + '\\b', true, false).draw();
        var weekLabel = "Week " + week_status;

        var startOfWeek = moment().isoWeek(week_status).startOf('isoWeek');
        var endOfWeek = moment().isoWeek(week_status).endOf('isoWeek');
        // Format the start and end dates as desired
        var startDate = startOfWeek.format('DD-MM-YYYY');
        var endDate = endOfWeek.format('DD-MM-YYYY');
        // Create the week range label
        var weekRangeLabel =  '(' + startDate + ' - ' + endDate + ')';
        // Create a paragraph element for the week range label
        var weekRangeText = jQuery('<p class="week-range-text">').text(weekRangeLabel);
      
        jQuery('.table-custom-filters').find('.week-range-text').remove();
        jQuery('.table-custom-filters').append(weekRangeText);
    });

    roleFilter.find("#role-filter").on('change', function() {
        var role_status = jQuery(this).val();
        //table.column(2).search(role_status).draw();
        if(role_status == ""){
            table.column(2).search('').draw();
        }
        else{
            table.column(2).search('^' + role_status + '$', true, false).draw();
        }
        
    });


// reset table filter on View team members
    var resetFilterBtn = jQuery('<button id="reset-filter-btn">Reset Filter</button>');
    jQuery('#team-members-table_filter').prepend(resetFilterBtn);
    jQuery("#reset-filter-btn").click(function(){
        jQuery("#team-members-table").DataTable().search("").draw();
        document.getElementById('status-filter').value="";
        table.column(7).search('').draw();
    });


    // Function to show/hide fields based on Team Lead selection
    function toggleFieldsVisibility() {
        var isLead = jQuery( '#team_member_islead' ).val();
        var usernameField = jQuery( '#username_field' );
        var passwordField = jQuery( '#password_field' );
        var leadingPercentageField = jQuery( '#leading_percentage_field' );
        var leadingEmailField = jQuery( '#leading_email_field' );

        if ( isLead === 'Yes' ) {
            usernameField.show();
            passwordField.show();
            leadingPercentageField.show();
            leadingEmailField.show();
        } else {
            usernameField.hide();
            passwordField.hide();
            leadingPercentageField.hide();
            leadingEmailField.hide();
        }
    }

        // Initial visibility setup on page load
        toggleFieldsVisibility();

        // Bind change event to Team Lead select field
        jQuery('#team_member_islead' ).on( 'change', function() {
            toggleFieldsVisibility();
        });

        jQuery('#team_member_reporting').select2({
            val: null,
            placeholder: 'Select an employee',
            width: '30%'
        });

});


jQuery('body').on('click', '.edit-evaluation', function(e) {
    jQuery('.work-rating-value').toggle();
    jQuery('.work-rating-value-field').toggle();

    jQuery('.work-rating-comment').toggle();
    jQuery('.work-rating-comment-field').toggle();
    
    
    jQuery('.team-management-value').toggle();
    jQuery('.team-management-value-field').toggle();
   
    jQuery('.work-management-comment').toggle();
    jQuery('.work-management-comment-field').toggle();

    jQuery('.save-evaluation').toggle();
    
    
e.preventDefault();
});

jQuery('body').on('click', '.save-evaluation', function(e) {
    window.location.reload();
});
 

 // Button click event
jQuery('#team-member-name-option').change(function() {

        jQuery('#team-member-name-field').toggle();
        

        jQuery.ajax({
            url: 'http://localhost/teams/wp-admin/admin-ajax.php', 
            type: 'POST',
            data: {
                action: 'fetch_webhr_api_data' 
            },
            success: function(response) {
                var selectOptions = '';
         // Access and use FullName, Email, and WebHR ID separately
         response.forEach(function(item) {
            var fullName = item[0]; 
            var designation = item[3]
             // Append the FullName as an option
             selectOptions += '<option value="' + fullName + '">' + fullName + ' - (' + designation +')</option>';
            
        });
         
        jQuery('#team-member-name').html(selectOptions);
     
        jQuery('#team-member-name').change(function() {
            var selectedOption = jQuery(this).val(); // Get the selected value
           

          // Find the selected option in the response array
                var selectedItem = response.find(function(item) {
                    return item[0] === selectedOption;
                });

                if (selectedItem) {
                    var selectedName = selectedItem[0];
                    var selectedEmail = selectedItem[1]; // Get the email of the selected option
                    var selectedWebHRID = selectedItem[2]; // Get the WebHR ID of the selected option
                    
                    // Populate the email and WebHR ID into separate text fields
                    jQuery('#title').val(selectedName);
                    jQuery('#team-member-name-input').val(selectedName);
                    jQuery('#title-prompt-text').html('');
                    jQuery('#team_member_email').val(selectedEmail);
                    jQuery('#team_member_webhr_id').val(selectedWebHRID);
                   
                }
        });

            },
            error: function(xhr, status, error) {

                console.log(error);
            }
        });
             jQuery('#team-member-name').select2({
                val: null,
                placeholder: 'Select an employee',
                width: '50%'
            });
            
        
  });






//   jQuery(document).ready(function () {
//     jQuery.ajax({
//         url: 'http://localhost/teams/wp-admin/admin-ajax.php', 
//         type: 'POST',
//         data: {
//             action: 'fetch_webhr_api_leaves_data' 
//         },
//         success: function(response) {
//             console.log(response);

//         },
//         error: function(xhr, status, error) {

//             console.log(error);
//         },
//     });
         
    
//   });
