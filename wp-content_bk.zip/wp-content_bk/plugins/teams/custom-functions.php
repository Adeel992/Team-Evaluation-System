<?php 

// Enqueue DataTables scripts and stylesheets
function team_members_enqueue_scripts() {
    wp_enqueue_script( 'jquery' );

    wp_enqueue_script( 'datatables', 'https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js', array( 'jquery' ), '1.13.4', true );
    wp_enqueue_style( 'datatables', 'https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css', array(), '1.13.4' );

    wp_enqueue_style( 'font-awesome', plugin_dir_url( __FILE__ ) . 'assets/font-awesome/css/font-awesome.min.css', array(), '5.15.4' );

    wp_enqueue_style( 'datepicker', 'https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.10.0/css/bootstrap-datepicker.min.css' );
    wp_enqueue_script( 'date-picker', 'https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.10.0/js/bootstrap-datepicker.min.js', array(), '5.15.4' );

    wp_enqueue_style( 'select', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css' );
    wp_enqueue_script( 'select', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', array(), '5.15.4' );

    wp_enqueue_script('moment' , 'https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js', array(), '5.15.4'  );
     
    
    wp_enqueue_script( 'custom', plugin_dir_url( __FILE__ ) . 'js/custom.js', array( 'jquery' ), '1.0', true );
    wp_enqueue_style( 'style', plugin_dir_url( __FILE__ ) . 'css/style.css');

}
add_action( 'admin_enqueue_scripts', 'team_members_enqueue_scripts' );
add_action( 'wp_enqueue_scripts', 'team_members_enqueue_scripts' );


/* Shortcode for displaying team members table */ 
function team_members_display_shortcode( $atts ) {
    ob_start();
    team_members_display_table();
    return ob_get_clean();
}
add_shortcode( 'team_members_table', 'team_members_display_shortcode' );

// Allow users to view and manage their own team members
function team_members_filter_query_by_author( $query ) {
    if ( is_admin() && $query->is_main_query() && $query->get( 'post_type' ) == 'team_member' ) {
        $current_user_id = get_current_user_id();
        $query->set( 'author', $current_user_id );
    }
}
add_action( 'pre_get_posts', 'team_members_filter_query_by_author' );

function add_author_support_to_posts() {
    add_post_type_support( 'team_member', 'author' ); 
 }
 add_action( 'init', 'add_author_support_to_posts' );

// Grant "editor" role access to the custom admin menu page
function team_members_grant_editor_access() {
    $editor_role = get_role( 'employee' );
    $editor_role->add_cap( 'edit_posts' );
}
add_action( 'admin_init', 'team_members_grant_editor_access' );

// Add filter to include custom template for team_member single view
function team_members_single_template( $template ) {
    if ( is_singular( 'team_member' ) ) {
        $template = plugin_dir_path( __FILE__ ) . 'templates/single-team_member.php';
    }
    return $template;
}
add_filter( 'template_include', 'team_members_single_template' );

function team_members_publish_user_creation(  $post_id, $post ) {
    // Check if the post is a team member and is being published
    if ( 'team_member' === $post->post_type )  {
     

    // Get the username, password, and email from post meta
    $username = get_post_meta( $post_id, '_team_member_email', true );
    $password = get_post_meta( $post_id, '_team_member_password', true );
    $email = get_post_meta( $post_id, '_team_member_email', true );
    $percentage = get_post_meta( $post_id, '_team_member_percentage', true );


    // Validate the username, password, and email
    if ( ! empty( $username ) && ! empty( $password ) && ! empty( $email ) && ! empty (  $percentage ) ) {
      
   
            // Create the user
            $user_id = wp_create_user( $username, $password, $username );

            // Check if the user was created successfully
            if ( ! is_wp_error( $user_id ) ) {
                // Assign the "administrator" role to the user
                $user = new WP_User( $user_id );
                $user->set_role( 'employee' );
            }
    }
}

}
add_action( 'wp_insert_post', 'team_members_publish_user_creation', 20, 2 );


//save post values into DB
function store_team_member_data( $post_id ) {
    // Check if the post is a team member
     // Get the post status
     $post_status = get_post_status( $post_id );

    //if ( 'team_member' === get_post_type( $post_id ) && 'draft' !== $post_status) {
        if ('team_member' === get_post_type( $post_id ) && 'publish' === get_post_status( $post_id ) ){
        global $wpdb;

        // Retrieve the necessary post data

        $name = get_post_meta( $post_id, '_team_member_name', true );
        $designation = get_post_meta( $post_id, '_team_member_designation', true );
        $email = get_post_meta( $post_id, '_team_member_email', true );
        $webhr_id = get_post_meta( $post_id, '_team_member_webhr_id', true );
        $report_to = get_post_meta( $post_id, '_team_member_report_to', true );
        $is_lead = get_post_meta( $post_id, '_team_member_is_lead', true );
        $percentage = get_post_meta( $post_id, '_team_member_percentage', true );
        $member_status = get_post_meta( $post_id, '_team_member_status', true );
       // $lead_username = get_post_meta( $post_id, '_team_member_username', true );
        $lead_password = get_post_meta( $post_id, '_team_member_password', true );
        $work_rating_value = get_post_meta( $post_id, '_team_member_work_rating_value', true );
        $work_rating_comment = get_post_meta( $post_id, '_team_member_work_rating_comment', true );
        $management_rating = get_post_meta( $post_id, '_team_member_management_rating', true );
        $management_comment = get_post_meta( $post_id, '_team_member_management_comment', true );

        $current_week = date( 'W' );
        $current_year = date( 'Y' );
        // Prepare the data to be inserted into the custom table
        $data = array(
            'post_id' => $post_id,
            'user_name' => $name,
            'user_designation' => $designation,
            'user_email' => $email,
            'user_webhrID' => $webhr_id,
            'user_report_to' => $report_to,
            'user_is_lead' => $is_lead,
            'user_lead_percentage' => $percentage,
            'user_status' => $member_status,
            'lead_username' => '',
            'lead_password' => $lead_password,
            'work_rating_value' => $work_rating_value,
            'work_rating_comment' => $work_rating_comment,
            'management_rating' => $management_rating,
            'management_comment' => $management_comment,
            'week_number'  => $current_week,
            'year'  => $current_year,
        );

        $existing_record = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}team_members WHERE post_id = %d AND user_webhrID AND week_number = %d AND year = %d",
                $post_id,
                $webhr_id,
                $current_week,
                $current_year
            )
        );        
        if ( $existing_record ) {
        // Insert the data into the custom table
        $table_name = $wpdb->prefix . 'team_members';
        $wpdb->update( $wpdb->prefix . 'team_members', $data, array( 'post_id' => $post_id )  );
        
        }
        else{
            $table_name = $wpdb->prefix . 'team_members';
            $wpdb->insert( $table_name, $data );
        }
        
    }
}
add_action( 'wp_insert_post', 'store_team_member_data', 20, 1 );

// Hook into before_delete_post action
add_action('delete_post', 'delete_custom_table_entry');
// Function to delete custom table entry when a post is deleted
function delete_custom_table_entry($post_id) {
    // Check if the post being deleted is of the desired post type
    if (get_post_type($post_id) === 'team_member') { // Replace 'your_post_type' with your actual post type
        global $wpdb;
        $table_name = $wpdb->prefix . 'team_members'; // Replace 'custom_table_name' with your actual table name

        // Delete the entry from the custom table using the post_id
        $wpdb->delete(
            $table_name,
            array('post_id' => $post_id),
            array('%d')
        );
    }
}


// get WebHR data with API
function fetch_webhr_api_data() {

    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => 'https://api.webhr.co/api/2/api?module=Employees&submodule=Employees&request=List',
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'GET',
      CURLOPT_HTTPHEADER => array(
        'Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiJLSXZlcHVNZjRYQ2JmMElwIiwianRpIjoiNjE3MGFiNDVlZGQ2NzEwMWE5Y2FlYzlhYjNkYTQwYmFiMDdiOGJhYzk3MDA4MzQxZGVlYjMwNjQ4ZDI5ZmRkMDk5NWQyZmY3NTJjZmUwZTgiLCJpYXQiOjE2NTgyMTgwMjUuNjczNDA5LCJuYmYiOjE2NTgyMTgwMjUuNjczNDEyLCJleHAiOjE2ODk3NTQwMjUuNjUzMzQ0LCJzdWIiOiJhZG1pbiIsInNjb3BlcyI6WyJGdWxsX0FjY2VzcyIsIkVtcGxveWVlcyIsIlRpbWVzaGVldCJdfQ.kOcU_SBGaexmA23rS9dqq760dgK8D_FMK7vLArYn9Me3J_3vWwtLVqaTD-5_k6_7i_zioDFM1MKdtZUEO4XcdqLlY6j-9IXaf7UCCtJgUqSlR1GKW7Ka_GKWDNt9hBVOyfAAUnEYhPGORePZ5sdbVeMloQNgJXZMmnY0yXQpJs_2goEj25OHQkd0xvsRE86ELbEmZ_tEeA3-sARO-sOHuki-a9cbwKHZdpguWetBpPhNnL7F4Qa-E0g_RLSMf-qIeWyWqHCNZwAv6u39Jm0IwqlSFmBjMxmUXM3pzenJcMeKCYeULS-UOS-8vsX0oUzaiuA8bxI9KuuJ5waeU_HuAg',
        'Cookie: PHPSESSID=ab2k8l2u6l2desb16j6n599b6k'
      ),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    
    $dataArray = json_decode($response, true);
    $fullNames = array(); // Array to store FullName values
    $emailAddress = array(); // Array to store FullName values
    $EmployeeId = array(); // Array to store FullName values

    foreach ($dataArray as $item) {
        if (isset($item['FullName']) && isset($item['EmailAddress']) && isset($item['EmployeeId'])) {
            $fullNames[] = $item['FullName'];
            $emailAddress[] = $item['EmailAddress'];
            $EmployeeId[] = $item['UserName'];
            $designation[] = $item['Designation'];
             }
    }
    $mergedArray = array_map(null, $fullNames, $emailAddress, $EmployeeId, $designation);
    wp_send_json($mergedArray); // Send JSON response
    exit;
}
add_action('wp_ajax_fetch_webhr_api_data', 'fetch_webhr_api_data');
add_action('wp_ajax_nopriv_fetch_webhr_api_data', 'fetch_webhr_api_data');


// get ranges between dates

// Function to get all dates between two dates
function getDatesBetween($startDate, $endDate) {
    $dates = array($startDate);
    $currentDate = $startDate;
    while ($currentDate < $endDate) {
        $currentDate = date('Y-m-d', strtotime($currentDate . ' +1 day'));
        $dates[] = $currentDate;
    }
    return $dates;
}

//Leaves data from webhr API
function fetch_webhr_api_leaves_data() {

    $curl = curl_init();
    $previousWeekStartDate = date('Y-m-d', strtotime('last Monday'));
    $previousWeekEndDate = date('Y-m-d', strtotime('next Friday'));


    $params = array(
        "StartDate" => $previousWeekStartDate,
        "EndDate" => $previousWeekEndDate,
    );
    $params = json_encode($params);
    
    curl_setopt_array($curl, array(
      CURLOPT_URL => 'https://api.webhr.co/api/2/api?module=Timesheet&submodule=Leaves&request=List&params='.$params,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'GET',
      CURLOPT_HTTPHEADER => array(
        'Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiJLSXZlcHVNZjRYQ2JmMElwIiwianRpIjoiNjE3MGFiNDVlZGQ2NzEwMWE5Y2FlYzlhYjNkYTQwYmFiMDdiOGJhYzk3MDA4MzQxZGVlYjMwNjQ4ZDI5ZmRkMDk5NWQyZmY3NTJjZmUwZTgiLCJpYXQiOjE2NTgyMTgwMjUuNjczNDA5LCJuYmYiOjE2NTgyMTgwMjUuNjczNDEyLCJleHAiOjE2ODk3NTQwMjUuNjUzMzQ0LCJzdWIiOiJhZG1pbiIsInNjb3BlcyI6WyJGdWxsX0FjY2VzcyIsIkVtcGxveWVlcyIsIlRpbWVzaGVldCJdfQ.kOcU_SBGaexmA23rS9dqq760dgK8D_FMK7vLArYn9Me3J_3vWwtLVqaTD-5_k6_7i_zioDFM1MKdtZUEO4XcdqLlY6j-9IXaf7UCCtJgUqSlR1GKW7Ka_GKWDNt9hBVOyfAAUnEYhPGORePZ5sdbVeMloQNgJXZMmnY0yXQpJs_2goEj25OHQkd0xvsRE86ELbEmZ_tEeA3-sARO-sOHuki-a9cbwKHZdpguWetBpPhNnL7F4Qa-E0g_RLSMf-qIeWyWqHCNZwAv6u39Jm0IwqlSFmBjMxmUXM3pzenJcMeKCYeULS-UOS-8vsX0oUzaiuA8bxI9KuuJ5waeU_HuAg',
        'Cookie: PHPSESSID=ab2k8l2u6l2desb16j6n599b6k'
      ),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    
    $dataArray = json_decode($response, true);
    foreach ($dataArray as $item) {
        if (isset($item['UserName'])) {
            $user_id =  $item['UserName'];
            $user_firstname = $item['FirstName'];
            $leavehours = $item['LeaveHours'];
            $leaveduration = $item['LeaveDuration'];
            $leavefrom = $item['LeaveFrom'];
            $leaveto = $item['LeaveTo'];
       
            if ($leaveduration != 0.5){
            // Check if all leave dates are within the previous week range
            $leaveDates = getDatesBetween($leavefrom, $leaveto);
            $myDates = getDatesBetween($previousWeekStartDate, $previousWeekEndDate);
            $commonDates = array_intersect(getDatesBetween($previousWeekStartDate, $previousWeekEndDate), $leaveDates);
            $numCommonDates = count($commonDates);
            $user_leaves_hour = $numCommonDates * 8;
            }
            else{
                $user_leaves_hour = 0.5 * 8;
            }
            

             // Update user_on_leaves column for matching user_name in wp_team_members table
             global $wpdb;
             $table_name = $wpdb->prefix . 'team_members';
             $wpdb->query(
                 $wpdb->prepare(
                     "UPDATE $table_name SET user_on_leaves = %s WHERE user_webhrID = %s",
                     $user_leaves_hour,
                     $user_id
                 )
             );
            
         }
      
    }
   wp_send_json($dataArray); // Send JSON response
   exit;
   
}
add_action('wp_ajax_fetch_webhr_api_leaves_data', 'fetch_webhr_api_leaves_data');
add_action('wp_ajax_nopriv_fetch_webhr_api_leaves_data', 'fetch_webhr_api_leaves_data');


// Function to insert user data
/*function update_new_jira() {
    // Path to the CSV file
    $csv_file_path = 'http://localhost/teams/wp-content/uploads/2023/06/jira_work_logs.csv';

    // Read the CSV file into an array
    $csv_data = array_map('str_getcsv', file($csv_file_path));
    // Extract the column headers
    $headers = array_shift($csv_data);


    // Find the index of the 'Email' and 'time_spend_hrs' columns
    $user_email_index = array_search('Email', $headers);
    $jira_work_logs_index = array_search('time_spent_hrs', $headers);


    // Create an array to store the total jira_work_logs for each user
    $combined_work_logs = array();

    // Loop through the CSV data
    foreach ($csv_data as $row) {
        $user_email = $row[$user_email_index];
        $jira_work_logs = (int)$row[$jira_work_logs_index];
        // Convert the value to integer if it's numeric

        // If the user_email already exists in the array, add the jira_work_logs value
        if (isset($combined_work_logs[$user_email])) {
            $combined_work_logs[$user_email] += $jira_work_logs;
         
        } else {
            $combined_work_logs[$user_email] = $jira_work_logs;
        }
    }

    // Loop through the user_work_logs array and update the 'jira_work_logs' column in the WordPress table
    foreach ($combined_work_logs as $user_email => $jira_work_logs) {
      
          // Update the 'jira_work_logs' column in the WordPress table for the matching 'user_email'
          global $wpdb;
          $current_week = date( 'W' );
        
            $table_name = $wpdb->prefix . 'team_members';
            $wpdb->query(
                $wpdb->prepare(
                    "UPDATE $table_name SET jira_work_logs = %s WHERE user_email = %s AND week_number = %d",
                    $jira_work_logs,$user_email,$current_week )
            );
        
          
    }

    echo '<div class="notice notice-success"><p>Jira work logs updated successfully.</p></div>';
}

update_new_jira();*/
